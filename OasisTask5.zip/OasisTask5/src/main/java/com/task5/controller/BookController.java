package com.task5.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import com.task5.dto.UserDto;
import com.task5.entity.Book;
import com.task5.entity.MyBookList;
import com.task5.entity.Product;
import com.task5.entity.User;
import com.task5.repo.ProductRepository;
import com.task5.service.BookService;
import com.task5.service.MyBookListService;
import com.task5.service.ProductService;
import com.task5.service.UserService;

import jakarta.validation.Valid;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;

@Controller
public class BookController {
	@Autowired
    private ProductRepository repo;
	
	private UserService userService;
	private ProductService productService;
	@Autowired
	   private ProductService servicee;
	
	@Autowired
	private BookService service;
	
	@Autowired
	private MyBookListService myBookService;
	
	public BookController(UserService userService, ProductService productService) {

		this.userService = userService;
		this.productService = productService;

	}
	
	@GetMapping("/login")
	public String loginForm()
	{
		return "login";
	}
	
	@GetMapping("/register")
	public String showRegistrationForm(Model model) {
		UserDto user = new UserDto();
		model.addAttribute("user", user);
		return "register";
	}
	
	@PostMapping("/register/save")
	public String registration(@Valid @ModelAttribute("user") UserDto user, BindingResult result, Model model) {
		User existing = userService.findByEmail(user.getEmail());
		if (existing != null) {
			result.rejectValue("email", null, "There is already an account registered with that email");
		}

		if (result.hasErrors()) {
			model.addAttribute("user", user);
			return "register";
		}
		userService.saveUser(user);
		return "redirect:/register?success";
	}
	
	@GetMapping("/")
	public String home() {
		return "home";
	}
	
	@GetMapping("/book_register")
	public String bookRegister() {
		return "bookRegister";
	}
	
	@GetMapping("/available_books")
	public ModelAndView getAllBook() {
		List<Book>list=service.getAllBook();
//		ModelAndView m=new ModelAndView();
//		m.setViewName("bookList");
//		m.addObject("book",list);
		return new ModelAndView("bookList","book",list);
	}
	
	@PostMapping("/save")
	public String addBook(@ModelAttribute Book b) {
		service.save(b);
		return "redirect:/available_books";
	}
	@GetMapping("/my_books")
	public String getMyBooks(Model model)
	{
		List<MyBookList>list=myBookService.getAllMyBooks();
		model.addAttribute("book",list);
		return "myBooks";
	}
	@RequestMapping("/mylist/{id}")
	public String getMyList(@PathVariable("id") int id) {
		Book b=service.getBookById(id);
		MyBookList mb=new MyBookList(b.getId(),b.getName(),b.getAuthor(),b.getPrice());
		myBookService.saveMyBooks(mb);
		return "redirect:/my_books";
	}
	
	@RequestMapping("/editBook/{id}")
	public String editBook(@PathVariable("id") int id,Model model) {
		Book b=service.getBookById(id);
		model.addAttribute("book",b);
		return "bookEdit";
	}
	@RequestMapping("/deleteBook/{id}")
	public String deleteBook(@PathVariable("id")int id) {
		service.deleteById(id);
		return "redirect:/available_books";
	}
	
	@GetMapping("/show")
	public String show(Model model)
	{
		List<Product> list=servicee.getAllproduct();
		model.addAttribute("value",list);
		return "adminData";
	}
	
	@GetMapping("/AdminDash")
	public String listRegisteredUsers(Model model) {
		int totalUsers = userService.getTotalUsers();
		int count = totalUsers - 1;
		model.addAttribute("totalUsers", count);

		int totalProduct = productService.getTotalProduct();
		model.addAttribute("totalProduct", totalProduct);

		return "designn";
	}
	
	@GetMapping("/AddProduct")
    public String addProductForm(Model model) {
    	List<Product> list=repo.findAll();
	    model.addAttribute("list",list);
		return "registerform";
    }
	@PostMapping("/insertt")
	public String insert(@ModelAttribute Product pr)
	{
		servicee.saveproduct(pr);
		return "redirect:/AddProduct";
	}
	@GetMapping("/edit")
	public String edituserbyid(@RequestParam Integer id,Model model)
	{
		Product ad=servicee.getproductById(id);
		model.addAttribute("ad",ad);
		return "adminedit";
	}
	
	@PostMapping("/update")
	public String updaterecord(@ModelAttribute Product pr)
	{
		servicee.updateproduct(pr);
		return "redirect:show";
	}
	
	@GetMapping("/remove")
	public String deleteuser(@RequestParam Integer id)
	{
		servicee.deleteproductById(id);
		return "redirect:show";
	}
}