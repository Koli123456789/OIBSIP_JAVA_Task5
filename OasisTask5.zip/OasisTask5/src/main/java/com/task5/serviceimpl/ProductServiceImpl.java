package com.task5.serviceimpl;

import java.util.List;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task5.entity.Product;
import com.task5.repo.ProductRepository;
import com.task5.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository repo;
	
	@Override
	public void saveproduct(Product pr) 
	{
		repo.save(pr);
		
	}
	
	@Override
	public List<Product> getAllproduct()
	{
		
		return repo.findAll();
	}
	
	@Override
	public Product getproductById(Integer id) {
		Optional<Product> opt=repo.findById(id);
		if(opt.isEmpty())
		{
			return null;
		}
		return opt.get();
	}
	
	@Override
	public void updateproduct(Product pr)
	{
		repo.save(pr);
		
	}
	
	@Override
	public void  deleteproductById(Integer id)
	{
		repo.deleteById(id);
		
	}

	@Override
	public int getTotalProduct() {
		return (int) repo.count();
	}
}
