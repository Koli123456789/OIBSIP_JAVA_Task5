package com.task5.service;

import java.util.List;

import com.task5.entity.Product;

public interface ProductService {

	
   void saveproduct(Product pr); //insert record
	
	List<Product> getAllproduct(); //show record
	
	Product getproductById(Integer id); //get single record by user id
	
	void updateproduct(Product pr); //update record
	
	void deleteproductById(Integer id); //delete record
	
	 public int getTotalProduct() ;
}
  