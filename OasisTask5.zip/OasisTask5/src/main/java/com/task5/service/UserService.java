package com.task5.service;

import java.util.List;

import com.task5.dto.UserDto;
import com.task5.entity.User;




public interface UserService {
	 void saveUser(UserDto userDto);

	    User findByEmail(String email);

	    List<UserDto> findAllUsers();
	    
	    public int getTotalUsers() ;
   
		/* public Long findUserIdByMail(String email); */

}

