package com.task5.repo;

import java.util.Optional;


import org.springframework.data.jpa.repository.JpaRepository;

import com.task5.entity.User;





public interface UserRepository extends JpaRepository<User, Long> {
    User findByEmail(String email);
    boolean existsByRoles_Name(String roleName);
    
    
}