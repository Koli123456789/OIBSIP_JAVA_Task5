package com.task5.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.task5.entity.Product;


public interface ProductRepository extends JpaRepository<Product, Integer> {

}
