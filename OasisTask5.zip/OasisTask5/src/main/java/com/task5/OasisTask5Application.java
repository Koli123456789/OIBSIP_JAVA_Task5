package com.task5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OasisTask5Application {

	public static void main(String[] args) {
		SpringApplication.run(OasisTask5Application.class, args);
	}

}

